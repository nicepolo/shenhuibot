# 神回AI Telegram Bot

業務×感情×行業話術神器

## 部署到 Railway

1. 前往 https://github.com 建立新 repo（名稱：shenhuibot）
2. 上傳這個資料夾的所有檔案
3. 前往 https://railway.app 登入
4. New Project → Deploy from GitHub repo → 選 shenhuibot
5. 設定環境變數（可選，已內建）：
   - BOT_TOKEN = 你的 Telegram Bot Token
   - GEMINI_KEY = 你的 Gemini API Key
6. Deploy！

## 指令

- /模式 — 切換話術情境
- /語氣 — 切換回覆風格  
- /說明 — 使用說明
